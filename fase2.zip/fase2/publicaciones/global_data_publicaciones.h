
#ifndef GLOBAL_DATA_PUBLICACIONES_H
#define GLOBAL_DATA_PUBLICACIONES_H

#include "listaDobleEnlazada/listaD_enlazadaP.h"  // la definición de ListaDoblementeEnlazadaP

extern ListaDoblementeEnlazadaP listaGlobal_publicaciones;

#endif