#include "registroPublicaciones.h"
#include "../usuarios/global_usuariosAVL.h"
#include "comentario/listaComentarios/lista_comentarios.h"


#include <string>

ListaDoblementeEnlazadaP listaGlobal_publicaciones; 
 
bool validarFormatoFecha(const std::string& fecha) {
    int dia = 0, mes = 0, anio = 0;
    char delim1, delim2;

    // Separar la fecha usando '/' como delimitador
    std::istringstream ss(fecha);
    ss >> dia >> delim1 >> mes >> delim2 >> anio;

    // Validar formato general
    if (delim1 != '/' || delim2 != '/' || ss.fail()) {
        return false;
    }

    // Validar día, mes y año
    if (dia < 1 || dia > 31 || mes < 1 || mes > 12) {
        return false;
    }

    // Validar días específicos de febrero y meses de 30 días
    if (mes == 2) {
        bool esBisiesto = (anio % 4 == 0 && (anio % 100 != 0 || anio % 400 == 0));
        if (dia > (esBisiesto ? 29 : 28)) {
            return false;
        }
    } else if (mes == 4 || mes == 6 || mes == 9 || mes == 11) {
        if (dia > 30) {
            return false;
        }
    }

    // Si todo está bien, retorna true
    return true;
}
/*
    1) verificar si el arbol global de usuarios no este vacia.
    2) recorrer la arbolGlobal_usuarios hasta encontrar un correo con el que coincida el paramtreo correo
*/
void verificarCorreo_publicacion(const std::string& correo, const std::string& contenido, const std::string& fecha, const std::string& hora, lista_comentarios lista_comentarios) {
    // 1) Verificar el formato de la fecha de la publicación
    if (!validarFormatoFecha(fecha)) {
        std::cout << "Error: Formato de fecha inválido. Debe ser DD/MM/YYYY." << std::endl;
        return;
    }

    // 2) Verificar que el árbol global de usuarios no esté vacío
    if (arbolGlobal_usuarios.getRaiz() == nullptr) {
        std::cout << "Error: No hay usuarios en la aplicación." << std::endl;
        return;
    }

    // Buscar el usuario por correo en el árbol AVL
    NodoAVL* usuarioEncontrado = arbolGlobal_usuarios.buscarPorCorreo(correo);

    if (usuarioEncontrado != nullptr) {
        // Usuario encontrado, crear y asignar la publicación
        Publicacion nuevaPublicacion(correo, contenido, fecha, hora);

        // recorrer la lista lista_comentarios y agreagar cada comentario al nodo
        //nuevaPublicacion.get

        asignarListaGlobal_publicaciones(nuevaPublicacion);
        //asignarListaPersonal_publicaciones(nuevaPublicacion, correo, fecha);
        std::cout << "Publicación creada y asignada correctamente." << std::endl << std::endl;
    } else {
        std::cout << "Error: El correo no corresponde a ningún usuario registrado." << std::endl;
    }
}


// asignar a listaGlobal_publicaciones
void asignarListaGlobal_publicaciones(Publicacion publicacion) {
    // Agregar la publicación a la lista global de publicaciones
    listaGlobal_publicaciones.append(publicacion);
}


/*
void asignarBSTpersonal(const Publicacion& nuevaPublicacion, const std::string& correo, const std::string& fecha) {
    // Buscar el usuario por correo en el árbol AVL global
    NodoAVL* usuarioEncontrado = arbolGlobal_usuarios.buscarPorCorreo(correo);
    
    if (usuarioEncontrado == nullptr) {
        std::cout << "Error: Usuario no encontrado." << std::endl;
        return;
    }
    
    Usuarios& usuario = usuarioEncontrado->getData();
    
    // Agregar la publicación al BST personal del usuario
    NodoBST* nodoFecha = usuario.getBST_feedPublicaciones().insert(fecha);
    nodoFecha->getListaPublicaciones().append(nuevaPublicacion);
    
    // Agregar la publicación al BST de los amigos del usuario
    for (int amigoID : usuario.getLista_amigos().size()) {
        NodoAVL* amigoEncontrado = arbolGlobal_usuarios.buscarPorID(amigoID);
        if (amigoEncontrado != nullptr) {
            Usuarios& amigo = amigoEncontrado->getData();
            NodoBST* nodoFechaAmigo = amigo.getBST_feedPublicaciones().insert(fecha);
            nodoFechaAmigo->getListaPublicaciones().append(nuevaPublicacion);
        }
    }
}*/

/*
    la publicación debe verse en el feed de los amigos del usuario.
    por lo tanto se recorrera la lista de amigos (tienen el ID)
    y a cada usuario de esa lista se le agregara a su lista personal de publicaciones la Publicacion actual.

    si la publicación ya se encuentra no se agrega.

    son 2 asignaciones:
        la primera a ListaCircular_Dpp lista_publicacionesP;
        la segunda a ListaCircular_Dpp lista_publicacionesP de cada usuario que este en la lista de amigos 


void asignarListaPersonal_publicaciones(Publicacion publicacion, std::string correo) {
    // 1. Recorrer la lista global de usuarios para encontrar el usuario con el correo dado
    usuarios_Nodo* usuarioActual = listaGlobal_usuarios.getPrimero();
    while (usuarioActual != nullptr) {
        if (usuarioActual->getDato().getCorreo() == correo) {
            // Agregar la publicación a la lista de publicaciones del usuario
            usuarioActual->getDato().agregarPublicacion(publicacion);
            
            // 2. Recorrer la lista de amigos del usuario
            listaSimpleEnlazada& listaAmigos = usuarioActual->getDato().getLista_amigos();
            Nodo* amigoActual = listaAmigos.getPrimero();
            while (amigoActual != nullptr) {
                int idAmigo = amigoActual->getData();
                
                // Buscar el amigo en la lista global de usuarios
                usuarios_Nodo* amigoUsuario = listaGlobal_usuarios.getPrimero();
                while (amigoUsuario != nullptr) {
                    if (amigoUsuario->getDato().getID() == idAmigo) {
                        // Verificar si el usuario es realmente un amigo (para mayor seguridad)
                        if (amigoUsuario->getDato().esAmigo(usuarioActual->getDato().getID())) {
                            // Agregar la publicación a la lista de publicaciones del amigo
                            amigoUsuario->getDato().agregarPublicacion(publicacion);
                            std::cout<<"Publicación agregada a: "<<amigoUsuario->getDato().getNombres()<<std::endl;
                        }
                        break;  // Salir del bucle interno una vez que se encuentra el amigo
                    }
                    amigoUsuario = amigoUsuario->getSig();
                }
                
                amigoActual = amigoActual->getSig();
            }
            
            break;  // Salir del bucle principal una vez que se encuentra el usuario
        }
        usuarioActual = usuarioActual->getSig();
    }
}
*/



