#ifndef BST_PUBLI_H
#define BST_PUBLI_H
#include "nodoBST_publi.h"
#include <sstream>
#include <iostream>

class BST{
    private:
        NodoBST *raiz;

        NodoBST* insert(NodoBST *raiz, const std::string& fechaID);
        // Método privado para insertar recursivamente
        //NodoBST* insert(NodoBST *raiz, const std::string& fechaID);
        void postOrden(NodoBST *raiz, bool accion);
        void preOrden(NodoBST *raiz);
        void inOrden(NodoBST *raiz);
        void graph(NodoBST *raiz, std::ofstream &f);

        // Método auxiliar para comparar fechas
        //int compareFechas(const std::string& fecha1, const std::string& fecha2);

        

    public:
        BST();
        ~BST();

        //void insert(std::string fechaID);
         // Método público para insertar
        void insert(const std::string& fechaID);

        // Método auxiliar para comparar fechas
        int compareFechas(const std::string& fecha1, const std::string& fecha2);

        void preOrden();
        void inOrden();
        void postOrden();
        void graph();
};
#endif // BST_PUBLI_H