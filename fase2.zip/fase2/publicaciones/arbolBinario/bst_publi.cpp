#include "bst_publi.h"

BST::BST(){
    this->raiz = nullptr;
    std::cout << "BST constructor called" << std::endl;
}

BST::~BST(){
    postOrden(this->raiz, 1);
}

/*
void BST::insert(std::string fechaID){
    this->raiz = insert(this->raiz, fechaID);
}
*/

// Método público para insertar
void BST::insert(const std::string& fechaID) {
    std::cout << "hola" << std::endl;
    raiz = insert(raiz, fechaID);
    std::cout << "Fecha " << fechaID << " agregada exitosamente" << std::endl;

}

void BST::preOrden(){
    preOrden(this->raiz);
}

void BST::inOrden(){
    inOrden(this->raiz);
}

void BST::postOrden(){
    postOrden(this->raiz, 0);
}

void BST::graph(){

    // Ruta donde deseas guardar el archivo .dot y .png
    std::string outputDir = "/Users/gio/Desktop/Edd_2s24/lab_edd_2s24/-EDD-Proyecto_202100229/fase2/usuarios/reportes/";

    // Crear el archivo .dot en la ruta especificada
    std::ofstream outfile (outputDir + "bst.dot");
    outfile << "digraph G {" << std::endl;

    if(raiz != nullptr){
        graph(raiz, outfile);
    }

    outfile << "}" << std::endl;
    outfile.close();

    int returnCode = system("/opt/local/bin/dot -Tpng ./bst.dot -o ./bst.png");

    if(returnCode == 0){std::cout << "Command executed successfully." << std::endl;}
    else{std::cout << "Command execution failed or returned non-zero: " << returnCode << std::endl;}
}

void BST::graph(NodoBST *raiz, std::ofstream &f){
    if(raiz != nullptr){
        std::stringstream oss;
        oss << raiz;
        std::string nombre = oss.str();

        f << "Nodo" + nombre + "[label = \"" + raiz->getFechaID() + "\"]" << std::endl;
    
        if(raiz->getIzq() != nullptr){
            oss.str("");
            oss << raiz->getIzq();
            std::string izquierda = oss.str();
            f << "Nodo" << nombre + "->Nodo" + izquierda << std::endl;
            //Nodo<nombre_raiz>->Nodo<izquierda>;
        }

        if(raiz->getDrcha() != nullptr){
            oss.str("");
            oss << raiz->getDrcha();
            std::string derecha = oss.str();
            f << "Nodo" << nombre + "->Nodo" + derecha << std::endl;
            //Nodo<nombre_raiz>->Nodo<derecha>;
        }

        this->graph(raiz->getIzq(), f);
        this->graph(raiz->getDrcha(), f);
    }
}

void BST::preOrden(NodoBST *raiz){
    if(raiz != nullptr){
        std::cout << raiz->getFechaID() << ", ";
        preOrden(raiz->getIzq());
        preOrden(raiz->getDrcha());
    }
}

void BST::inOrden(NodoBST *raiz){
    if(raiz != nullptr){
        preOrden(raiz->getIzq());
        std::cout << raiz->getFechaID() << ", ";
        preOrden(raiz->getDrcha());
    }
}

void BST::postOrden(NodoBST *raiz, bool accion){
    if(raiz != nullptr){
        postOrden(raiz->getIzq(), accion);
        postOrden(raiz->getDrcha(), accion);
        if(!accion){std::cout << raiz->getFechaID() << ", ";}
        else{delete raiz;}
    }
}

// Implementación del método auxiliar para comparar fechas
int BST::compareFechas(const std::string& fecha1, const std::string& fecha2) {
    // Extraer día, mes y año de cada fecha
    int dia1, mes1, anio1, dia2, mes2, anio2;
    char delim;
    std::istringstream ss1(fecha1);
    std::istringstream ss2(fecha2);

    ss1 >> dia1 >> delim >> mes1 >> delim >> anio1;
    ss2 >> dia2 >> delim >> mes2 >> delim >> anio2;

    // Comparar año, luego mes, luego día
    if (anio1 != anio2) return anio1 - anio2;
    if (mes1 != mes2) return mes1 - mes2;
    return dia1 - dia2;
}

// Implementación del método de inserción modificado
NodoBST* BST::insert(NodoBST *raiz, const std::string& fechaID) {
    if (raiz == nullptr) {
        return new NodoBST(fechaID);
    }

    int comparacion = compareFechas(fechaID, raiz->getFechaID());

    if (comparacion < 0) {
        raiz->setIzq(insert(raiz->getIzq(), fechaID));
    } else if (comparacion > 0) {
        raiz->setDrcha(insert(raiz->getDrcha(), fechaID));
    }
    // Si la fecha ya existe (comparacion == 0), no hacemos nada
    // Alternativamente, podrías actualizar el nodo existente si es necesario
    return raiz;
}

/*

NodoBST* BST::insert(NodoBST *raiz, std::string fechaID){
    if(raiz == nullptr){raiz = new NodoBST(fechaID);}
    else if(fechaID < raiz->getFechaID()){raiz->setIzq(insert(raiz->getIzq(), fechaID));}
    else if(fechaID > raiz->getFechaID()){raiz->setDrcha(insert(raiz->getDrcha(), fechaID));}
    return raiz;
}
*/