#include "form_usuario.h"
#include "ui_form_usuario.h"
#include "mainwindow.h"

Form_usuario::Form_usuario(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Form_usuario)
{
    ui->setupUi(this);
    // Muestra la página vacía (page_white) al inicio
    ui->stackedWidget->setCurrentWidget(ui->page_white);
}

Form_usuario::~Form_usuario()
{
    delete ui;
}

void Form_usuario::on_btt_cerrarSesion_clicked()
{
    // Crear una instancia de la nueva ventana
    MainWindow *formLogin = new MainWindow();
    formLogin->show(); // regresa al login

    // Cierra la ventana actual (form_admin)
    this->close();

}

void Form_usuario::on_btt_buscar_clicked()
{
    ui->stackedWidget->setCurrentWidget(ui->page_buscar);
}


void Form_usuario::on_btt_publicaciones_clicked()
{
    ui->stackedWidget->setCurrentWidget(ui->page_publi);

}


void Form_usuario::on_btt_solicitudes_clicked()
{
    ui->stackedWidget->setCurrentWidget(ui->page_soli);

    // logica para manejar las solicitudes
    std::cout<<"--------------------------------"<< std::endl;
    registroSolicitudes("gio1", "gio4", "PENDIENTE");
    std::cout<<"--------------------------------"<< std::endl;
    registroSolicitudes("gio3", "gio6", "ACEPTADA");
    std::cout<<"--------------------------------"<< std::endl;
    registroSolicitudes("gio1", "gio4", "PENDIENTE");
    std::cout<<"--------------------------------"<< std::endl;
    registroSolicitudes("gio4", "gio1", "PENDIENTE");


    std::cout<<"--------------------------------"<< std::endl;
    registroSolicitudes("gio4", "gio1", "ACEPTADA");
    std::cout<<"--------------------------------"<< std::endl;
    registroSolicitudes("gio4", "gio1", "ACEPTADA");


    std::cout<<"--------------------------------"<< std::endl;
    registroSolicitudes("gio2", "gio4", "PENDIENTE");
    std::cout<<"--------------------------------"<< std::endl;
    registroSolicitudes("gio4", "gio2", "RECHAZADA");

    //std::cout<<"esta retornando: "<< result<< std::endl;

}


void Form_usuario::on_btt_reportes_clicked()
{
    ui->stackedWidget->setCurrentWidget(ui->page_reportes);

}


void Form_usuario::on_btt_perfil_clicked()
{
    ui->stackedWidget->setCurrentWidget(ui->page_perfil);
}

