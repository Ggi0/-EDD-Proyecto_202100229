
#ifndef GLOBAL_USUARIOS_AVL_H
#define GLOBAL_USUARIOS_AVL_H

#include "arbolAVL/avl_usuario.h"  

// Arbol AVL global en donde almacenar todos los usuarios.
extern AVL arbolGlobal_usuarios;

#endif 